import ExpenseItem from './ExpenseItem.js'
import './Expenses.css'
import Card from '../UI/Card.js';

function Expense(props){
    return (
        <Card className="expenses">
        <ExpenseItem
          title={props.item[0].title}
          amount={props.item[0].amount}
          date={props.item[0].date}
          location={props.item[0].location}
        />
        <ExpenseItem
          title={props.item[1].title}
          amount={props.item[1].amount}
          date={props.item[1].date}
          location={props.item[1].location}
        />
        <ExpenseItem
          title={props.item[2].title}
          amount={props.item[2].amount}
          date={props.item[2].date}
          location={props.item[2].location}
        />
        </Card>
    )
}

export default Expense;