import './ExpenseDate.css';
import Card from '../UI/Card.js';

function ExpenseDate(props) {

    const date = new Date(props.date);
    const year = date.toLocaleString('en-US', {month:'long'});
    const month = date.toLocaleString('en-Us',{day:'2-digit'});
    const day = date.getFullYear();

    return (
        <Card className='expense-date'>
            <div className="expense-date_month">{month}</div>
            <div className="expense-date_year">{year}</div>
            <div className="expense-date_day">{day}</div>
        </Card>
    )
}

export default ExpenseDate;