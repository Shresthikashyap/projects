import './ExpenseItem.css';

function ExpenseItem(props){
    const formattedDate = new Date(props.date).toString();

    return (
       
        <div className="expense-item">
            <div>{formattedDate}</div>
            <div className="expense-item_description"></div>
            <h2>{props.title}</h2>
            <div className="expense-item__price">${props.amount}</div>
            <div>{props.location}</div>
        </div>
    ) 
}

export default ExpenseItem 