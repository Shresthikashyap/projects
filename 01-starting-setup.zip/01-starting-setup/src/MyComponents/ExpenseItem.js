function ExpenseItem(){
    return (
       
        <div>
             <h2>Expense Item!</h2> 
             <p>
             Food Rs 10 <br />
             Petrol Rs 100  <br />
             Movies Rs 200
             </p>
        </div>
    ) 
}

export default ExpenseItem 