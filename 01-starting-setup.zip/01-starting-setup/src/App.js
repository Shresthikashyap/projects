import ExpenseItem from "./MyComponents/ExpenseItem";

function App() {

  const expenses = [
    {
      id:1,
      title:'expense1',
      amount:100,
      date: '2023-12-2',
      location:'Chennai'
    },
    {
      id:2,
      title:'expense2',
      amount:100,
      date: '2023-12-2',
      location:'Bangalore'
    },
    {
      id:1,
      title:'expense3',
      amount:100,
      date: '2023-12-2',
      location:'kerela'
    },
  ];

  return (
    <div>
      <h2>Let's get started!</h2>
      <ul>
        {expenses.map((expense) => (
          <ExpenseItem 
          title={expense.title} 
          amount={expense.amount} 
          date={expense.date}
          location={expense.location}/>
        ))}
      </ul>
    </div>
  );
}

export default App;
