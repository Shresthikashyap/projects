import ExpenseItem from "./MyComponents/ExpenseItem";

function App() {
  return (
    <div>
      <h2>Let's get started!</h2>
      <ExpenseItem>
      <div><h2>Food Rs 10

      Petrol Rs 100

      Movies Rs 200</h2>
      </div>
      </ExpenseItem>
    </div>
  );
}

export default App;
