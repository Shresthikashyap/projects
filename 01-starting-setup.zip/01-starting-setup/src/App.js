import Expenses from './MyComponents/Expenses/Expenses.js';

function App() {

  const expenses = [
    {
      title:'expense1',
      amount:100,
      date: '2023-12-2',
      location:'Chennai'
    },
    {
      title:'expense2',
      amount:100,
      date: '2023-12-2',
      location:'Bangalore'
    },
    {
      title:'expense3',
      amount:100,
      date: '2023-12-2',
      location:'kerela'
    },
  ];

  return (
    <div>
      <h2>Let's get started!</h2>
      <Expenses item={expenses}/>
    </div>
  );
}

export default App;
