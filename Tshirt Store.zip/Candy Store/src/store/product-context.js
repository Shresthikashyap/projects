import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProductContext = React.createContext({
    addproduct: (items) => {},
    products: [],
});

export default ProductContext;

export const ProductProvider = (props) => {
    const [products, updateProducts] = useState([]);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get('https://crudcrud.com/api/f4e9bc940ebc4d79b920258a41b99ce7/Products');
                console.log('get data ', response.data);
                updateProducts(response.data);
            } catch (error) {
                console.error('Error fetching cart data:', error);
            }
        };

        fetchProducts();
    }, []);

    const addProductToMenuHandler = async(...product) => {
        try {
            console.log('product ',product)
            const response = await axios.post('https://crudcrud.com/api/f4e9bc940ebc4d79b920258a41b99ce7/Products', { product });
            console.log('Product data saved successfully:', response.data);
            const newProduct = response.data;

            updateProducts((prevProducts) => [...prevProducts, newProduct]);

        } catch (error) {
            console.error('Error saving product data:', error);
        }
    };

    const productContext = {    
        products: products,
        addproduct: addProductToMenuHandler
    };

    return (
        <ProductContext.Provider value={productContext}>
            {props.children}
        </ProductContext.Provider>
    );
};
