import React, {useEffect, useState} from 'react';
import axios from 'axios';
import CartContext from './cart-context';

const CartProvider = props => {

    const [items,updateItems] = useState([]);
    const [total,updateTotal] = useState(0);

useEffect(()=>{            
   const fetchItems = async()=>{
        try{
            const response = await axios.get('https://crudcrud.com/api/f4e9bc940ebc4d79b920258a41b99ce7/TshirtStore');
            console.log('data ',response.data);

            updateItems(response.data);
          }
        
        catch (error) {
            console.error('Error fetching cart data:', error);
        }
      };
        
  fetchItems();
},[]);

    const addItemToCartHandler = async(item) =>{
        try {
          
            const response = await axios.post(`https://crudcrud.com/api/f4e9bc940ebc4d79b920258a41b99ce7/TshirtStore`, { item });
            console.log('Cart data saved successfully:', response.data);
            const newItem = response.data;
      
            alert('Item Added Successfully')

            updateItems([...items,newItem]);
      
            // const priceNumber = Number(total) + Number(newItem.item.price);
            // console.log('price ',priceNumber);
            // updateTotal(priceNumber);
      
          } catch (error) {
            console.error('Error saving cart data:', error);
          }
    };

    const removeItemFromCartHandler = async(_id) =>{
        console.log('pehle ',_id);

        try {
            const response = await axios.delete(`https://crudcrud.com/api/f4e9bc940ebc4d79b920258a41b99ce7/TshirtStore/${_id}`);
            console.log('Item removed successfully:', response);
               
              const removedItemIndex = items.findIndex((i) => i._id === _id);
             
              const updatedItems = [...items];
              const priceNumber = Number(total) - Number(updatedItems[removedItemIndex].item.price);         
              updateTotal(priceNumber);
        
              const filteredItems = items.filter(item => item._id !== _id)
              updateItems(filteredItems);
              
              alert('Item removed successfully!'); 
            } catch (error) {
            alert('sorry')
            console.error('Error removing item:', error);
          } 
    };

    const cartContext = {
        items: items,
        totalAmount: total,
        addItem: addItemToCartHandler,
        removeItem: removeItemFromCartHandler
    };

    return <CartContext.Provider value={cartContext}>
        {props.children}
        </CartContext.Provider>
}

export default CartProvider;