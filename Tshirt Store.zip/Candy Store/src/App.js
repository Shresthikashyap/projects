import React, { useState } from "react";

import Header from './components/Layout/Header';
import Tshirt from'./components/Tshirt/Tshirt';
import Cart from './components/Cart/Cart';
import CartProvider from "./store/CartProvider";
import { ProductProvider } from "./store/product-context";

function App() {

  const[cartIsShown, setCartVisible] = useState(false);
  

  const showCart = () => {
    setCartVisible(true);
  }

  const hideCart = () =>{
    setCartVisible(false)
  }

  return (
      <CartProvider>
        <ProductProvider>
        {cartIsShown && <Cart onClose={hideCart}/>}
        <Header onShowCart={showCart}/>
        <main>
           <Tshirt/>
        </main>
        </ProductProvider>
      </CartProvider>
  );
}

export default App;
