import React, { useContext } from "react";
import classes from './Cart.module.css';
import Modal from '../UI/Modal';
import CartContext from "../../store/cart-context";
import CartItem from "./CartItem";

const Cart = (props) =>{

    const cartCntxt = useContext(CartContext);

    const updatedCart = [];

    for(let i=0; i<cartCntxt.items.length; i++){
        const currentItem = cartCntxt.items[i];

        console.log('current item ****** ',currentItem)
        const existingItemCartIndex = updatedCart.findIndex((i) => i.item.id === currentItem.item.id)

    
        if(existingItemCartIndex === -1){
          currentItem.item.quantity = 1;
          updatedCart.push(currentItem);
        }else{
          updatedCart[existingItemCartIndex].item.quantity = Number(updatedCart[existingItemCartIndex].item.quantity)+1;
        } 

        const totalPrice = Number(currentItem.item.price) + cartCntxt.totalAmount;
        cartCntxt.totalAmount = totalPrice;
    }
    
    const hasItems = cartCntxt.items.length > 0;

    const cartItemRemoveHandler = (id) => {
        cartCntxt.removeItem(id);
    }

    const cartItemAddHandler = (item) => {
        console.log(item)
        
        cartCntxt.addItem({ ...item, large: item.large,medium:item.medium, small:item.small });
    };

    const cartitems = (<ul className={classes['cart-items']}>
        {console.log('cat**** ',updatedCart)}
        {updatedCart.map((cartItem) =>{
            return <CartItem 
            key={cartItem.item.id} 
            name={cartItem.item.name} 
            price={cartItem.item.price} 
            large={cartItem.item.large}
            medium={cartItem.item.medium}
            small={cartItem.item.small} 
            onRemove={cartItemRemoveHandler.bind(null,cartItem._id)}
            onAdd={cartItemAddHandler.bind(null,cartItem.item)}
            />;
        }
    )}
    </ul>
    )
    return (
        <Modal onClick={props.onClose}>
            {cartitems}
            <div className={classes.total}>
                <span>Total</span>
                <span>₹ {cartCntxt.totalAmount.toFixed(2)}</span>

                <div className={classes.actions}>
                    <button className={classes['button-alt']}  onClick={props.onClose}>Close</button>
                    {hasItems && <button className={classes.button}>Order</button>}
                </div>
            </div>
        </Modal>
    )
}

export default Cart;
