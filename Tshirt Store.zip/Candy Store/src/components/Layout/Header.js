import {Fragment} from 'react';

import HeaderCartButton from './HeaderCartButton';
import classes from './Header.module.css'

const Header = (props) =>{

    return (
        <Fragment>
            <header className={classes.header}>
                <h2>React Tshirts</h2>
                <HeaderCartButton  onClickButton={props.onShowCart}/>
            </header>
            <div className={classes['main-image']}>
                <img src='https://media.gq.com/photos/651f2e6d21c53954bf68f69d/16:9/w_1920,c_limit/heavyweight-t-shirt.jpg' 
                alt="A table full of delicious food" />
            </div>
            
        </Fragment>
    )
}

export default Header
