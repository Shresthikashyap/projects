import React,{useContext} from "react";

import CartIcon from "../Cart/CartIcon";
import CartContext from "../../store/cart-context";
import classes from './HeaderCartButton.module.css';

const HeaderCartButton = (props) =>{

    const cartCtx = useContext(CartContext);
  
    //console.log('in header acrt button', cartCtx.items)
    let quantity = 0;
    cartCtx.items.forEach((cartItem)=>{

        console.log(cartItem.item.quantity)
        quantity = quantity + 1;
    });
    

    return (
        <button className={classes.button} onClick={props.onClickButton}>
            <span className={classes.icon}>
                <CartIcon />
            </span>
            <span>Your Cart </span>
            <span className={classes.badge}> {quantity}</span>
        </button>
    ) 
}

export default HeaderCartButton