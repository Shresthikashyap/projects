// TshirtItem.js
import React from 'react';
import TshirtItemForm from './TshirtItemForm';
import classes from './TshirtItem.module.css';

const TshirtItem = (props) => {

    const quantity = Number(props.large) + Number(props.medium) + Number(props.small);

    return (
        <li className={classes.Tshirt}>
            <div>
                <h3>{props.name}</h3>
                <div className={classes.description}>{props.desc}</div>
                <div className={classes.price}>{props.price}</div>
            </div>
            <div>
                <TshirtItemForm id={props.id} quantity={quantity} items={props} />
            </div>
        </li>
    );
};

export default TshirtItem;
