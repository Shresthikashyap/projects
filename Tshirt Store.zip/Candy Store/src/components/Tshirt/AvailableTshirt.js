import React, { useContext} from 'react';
import classes from './AvailableTshirt.module.css';
import TshirtItem from './TshirtItem';
import Card from '../UI/Card';
import TshirtForm from './TshirtForm';
import ProductContext from '../../store/product-context';
// import axios from 'axios';

const AvailableTshirt = () => {
    const productCntxt = useContext(ProductContext);

    const addTshirtHandler = async(Tshirt) => {
        console.log('Tshirt ',Tshirt)
        productCntxt.addproduct({...Tshirt});
    };

    console.log(productCntxt.products)
    const availableTshirt = productCntxt.products.map((productGroup) => (
        productGroup.product.map((Tshirt) => (
            <TshirtItem 
                key={Tshirt.id}
                id={Tshirt.id}
                name={Tshirt.tshirt}
                desc={Tshirt.desc}
                price={Tshirt.price}
                large={Tshirt.large}
                medium={Tshirt.medium}
                small={Tshirt.small}
            />
        ))
    ));

    return (
        <section className={classes.Tshirt}>
            <Card>
                <TshirtForm onAddStock={addTshirtHandler} />
                {console.log('here',availableTshirt)}
                <ul>{availableTshirt}</ul>
            </Card>
        </section>
    );
};

export default AvailableTshirt;
