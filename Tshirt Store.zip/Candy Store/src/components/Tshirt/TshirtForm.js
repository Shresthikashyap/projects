import React, { useState } from 'react';

import classes from './TshirtForm.module.css'

const TshirtForm = (props) => {

    const [setTshirt,setTshirtHandler] = useState('');
    const [setDesc,setDescHandler] = useState('');
    const [setPrice,setPriceHandler] = useState('');
    const [setLargeQuantity,setLargeQuantityHandler] = useState('');
    const [setMediumQuantity,setMediumQuantityHandler] = useState('');
    const [setSmallQuantity,setSmallQuantityHandler] = useState('');



    const TshirtInputHandler = (event) =>{
        setTshirtHandler(event.target.value);
    }

    const descInputHandler = (event) =>{
        setDescHandler(event.target.value);
    }
 
    const priceInputHandler = (event) =>{
        setPriceHandler(event.target.value);
    }
    
    const largeQuantityInputHandler = (event) =>{
        setLargeQuantityHandler(event.target.value);
    }   
    
    const mediumQuantityInputHandler = (event) =>{
        setMediumQuantityHandler(event.target.value);
    } 

    const smallQuantityInputHandler = (event) =>{
        setSmallQuantityHandler(event.target.value);
    } 

    const formSubmitHandler = (event) => {
        event.preventDefault();

        const product = {
            id: Math.random().toString(),
            tshirt: setTshirt,
            desc:setDesc,
            price:setPrice,
            large:setLargeQuantity,
            medium:setMediumQuantity,
            small:setSmallQuantity
        }

        props.onAddStock(product);

        setTshirtHandler('');
        setDescHandler('');
        setPriceHandler('');
        setLargeQuantityHandler('');
        setMediumQuantityHandler('');
        setSmallQuantityHandler('');
    }
    return (
        <div className={classes.summary}>
            <h2>Tshirt Store</h2>
            <form onSubmit={formSubmitHandler}>
                <label>Tshirt Name</label>
                <input type="text" value={setTshirt} onChange={TshirtInputHandler}/>
                <label>Description</label>
                <input type="text" value={setDesc} onChange={descInputHandler}/>
                <label>Price</label>
                <input type="text" value={setPrice} onChange={priceInputHandler}/>
                <label>Large Quantity</label>
                <input type="number" value={setLargeQuantity} onChange={largeQuantityInputHandler}/>
                <label>Medium Quantity</label>
                <input type="number" value={setMediumQuantity} onChange={mediumQuantityInputHandler}/>
                <label>Small Quantity</label>
                <input type="number" value={setSmallQuantity} onChange={smallQuantityInputHandler}/>
                <button>Add Tshirt</button>
            </form>
        </div>
    )
}

export default TshirtForm