import React, { useContext, useState } from "react";
import Input from '../UI/Input.js'
import classes from './TshirtItemForm.module.css'
import CartContext from "../../store/cart-context.js";

const TshirtItemForm = (props) => {
    const cartContext = useContext(CartContext);
    const [localQuantity, setLocalQuantity] = useState(props.quantity || 'Out Of Stock');
    

    const addToCart = (event, quantity, size) => {
        event.preventDefault();
        console.log('size ',size);
        cartContext.addItem({ ...props.items, size });
        setLocalQuantity((prevQuantity) => prevQuantity - quantity);
    }

    return (
        <form className={classes.form}>
            {localQuantity > 0 ? (
            localQuantity > 0 &&
            <div className={classes.buttonContainer}> {console.log('in buttons ',props.items)}
            <button onClick={(e) => addToCart(e, 1, 'l')}>Large {props.items.large}</button>
            <button onClick={(e) => addToCart(e, 1, 'm')}>Medium {props.items.medium}</button>
            <button onClick={(e) => addToCart(e, 1, 's')}>Small {props.items.small}</button>
            </div> ): (
                <div style={{ color: 'red', fontSize: '24px' }}>Out of Stock</div>
            )}
        </form>
    );
}

export default TshirtItemForm;
