import { Fragment } from "react";

import AvailableTshirt from "./AvailableTshirt";

const Tshirt= () => {
    return(
        <Fragment>
            <AvailableTshirt/>
        </Fragment>
    )
}

export default Tshirt;